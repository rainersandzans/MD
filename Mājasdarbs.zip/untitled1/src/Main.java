import java.util.Scanner;
class Main {

    public static void main(String[] args) {

char operator;

Scanner input = new Scanner(System.in);

Double num1, num2, result;
System.out.println("Izvēlies darbību: +, -, * vai /");
operator = input.next().charAt(0);

System.out.println("Izvēlies pirmo skaitli");
num1 = input.nextDouble();

System.out.println("Izvēlies otro skaitli");
num2 = input.nextDouble();

        switch (operator) {
            case '+' -> {
                result = num1 + num2;
                System.out.println(result);
            }
            case '-' -> {
                result = num1 - num2;
                System.out.println(result);
            }
            case '*' -> {
                result = num1 * num2;
                System.out.println(result);
            }
            case '/' -> {
                result = num1 / num2;
                System.out.println(result);
            }
            default -> System.out.println("Kļūda");
        }
        input.close();
    }
}